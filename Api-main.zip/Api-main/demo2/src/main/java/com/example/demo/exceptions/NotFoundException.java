package com.example.demo.exceptions;

public final class NotFoundException extends Exception {
    public NotFoundException(String message) {
        super(message);
    }
}