package com.example.demo.repository;
import com.example.demo.entity.MetodoPago;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MetodoPagoRepository extends JpaRepository<MetodoPago, Long>{

}
