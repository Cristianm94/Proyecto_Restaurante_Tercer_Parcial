package com.example.demo.exceptions;

public final class BusinessException extends Exception {
    public BusinessException(String message) {
        super(message);
    }
}