package com.example.demo.repository;
import com.example.demo.entity.DetalleOrden;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DetalleOrdenRepository extends JpaRepository<DetalleOrden, Long>{

}
